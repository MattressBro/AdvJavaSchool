package Module4;

public abstract class Shape {
    //create the abstract methods
    public abstract double area();
    public abstract double perimeter();
}
